import pyttsx3
import datetime
import speech_recognition as sr
import wikipedia
import webbrowser as wb
import os
import random
import pyautogui
import pyjokes


engine = pyttsx3.init()
voices = engine.getProperty('voices')
engine.setProperty('voice', voices[1].id)  
engine.setProperty('rate', 150)
engine.setProperty('volume', 1)

def speak(audio) -> None:
    """Speaks the given text."""
    engine.say(audio)
    engine.runAndWait()

def time() -> None:
    """Tells the current time."""
    current_time = datetime.datetime.now().strftime("%I:%M:%S %p")
    speak(f"The current time is {current_time}")
    print(f"The current time is {current_time}")

def date() -> None:
    """Tells the current date."""
    now = datetime.datetime.now()
    speak(f"Today's date is {now.day} {now.strftime('%B')} {now.year}")
    print(f"Today's date is {now.day}/{now.month}/{now.year}")

def wishme() -> None:
    """Greets the user based on the time of day."""
    speak("Welcome back, sir!")
    print("Welcome back, sir!")

    hour = datetime.datetime.now().hour
    if 4 <= hour < 12:
        speak("Good morning!")
    elif 12 <= hour < 16:
        speak("Good afternoon!")
    elif 16 <= hour < 24:
        speak("Good evening!")
    else:
        speak("Good night, see you tomorrow.")

    assistant_name = load_name()
    speak(f"{assistant_name} at your service. Please tell me how may I assist you.")
    print(f"{assistant_name} at your service. Please tell me how may I assist you.")

def screenshot() -> None:
    """Takes a screenshot and saves it."""
    img = pyautogui.screenshot()
    img_path = os.path.expanduser("~\\Pictures\\screenshot.png")
    img.save(img_path)
    speak(f"Screenshot saved as {img_path}.")
    print(f"Screenshot saved as {img_path}.")

def takecommand() -> str:
    """Takes microphone input from the user and returns it as text."""
    r = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening...")
        r.pause_threshold = 1
        try:
            audio = r.listen(source, timeout=5)  # Listen with a timeout
        except sr.WaitTimeoutError:
            speak("I didn't hear anything. Please try again.")
            return None

    try:
        print("Recognizing...")
        query = r.recognize_google(audio, language="en-in")
        print(f"You said: {query}")
        return query.lower()
    except sr.UnknownValueError:
        speak("Sorry, I did not understand that.")
        return None
    except sr.RequestError:
        speak("Speech recognition service is unavailable.")
        return None
    except Exception as e:
        speak(f"An error occurred: {e}")
        print(f"Error: {e}")
        return None

def play_music(song_name=None):
    """Plays music from a collection in the user's Music directory."""
    song_dir = "C:/Users/admin/Music"  # Update with the correct path
    songs = [song for song in os.listdir(song_dir) if song.endswith((".mp3", ".wav", ".flac"))]

    if not songs:
        speak("No audio files found in your music collection.")
        print("No audio files found.")
        return

    # If a specific song name is given, find matching songs
    if song_name:
        matching_songs = [song for song in songs if song_name.lower() in song.lower()]
        if matching_songs:
            songs = matching_songs
        else:
            speak("Song not found. Playing a random song instead.")
            print("Song not found. Playing a random song.")

    # Shuffle songs before playing (optional)
    random.shuffle(songs)

    # Play each song one by one
    for song in songs:
        song_path = os.path.join(song_dir, song)
        speak(f"Playing {song}.")
        print(f"Playing: {song}")
        os.startfile(song_path)

def set_name() -> None:
    """Sets a new name for the assistant."""
    speak("What would you like to name me?")
    name = takecommand()

    if name:
        with open("assistant_name.txt", "w") as file:
            file.write(name)
        speak(f"Alright, I will be called {name} from now on.")
    else:
        speak("I didn't catch a name. Keeping my current name.")

def load_name() -> str:
    """Loads the assistant's name from a file, or uses a default name."""
    try:
        with open("assistant_name.txt", "r") as file:
            return file.read().strip()
    except FileNotFoundError:
        return "ASH"  # Default name
def open_whatsapp():
    """Opens WhatsApp Desktop or Web."""
    try:
        whatsapp_path = "C:/Users/min/AppData/Local/Packages/5319275A.WhatsAppDesktop_cv1g1gvanyjgm/LocalCache/Roaming"  
        if os.path.exists(whatsapp_path):
            speak("Opening WhatsApp Desktop.")
            print("Opening WhatsApp Desktop...")
            os.startfile(whatsapp_path)
        else:
            speak("WhatsApp Desktop not found. Opening WhatsApp Web.")
            print("Opening WhatsApp Web...")
            wb.open("https://web.whatsapp.com")
    except Exception as e:
        speak("An error occurred while opening WhatsApp.")
        print(f"Error: {e}")

def search_wikipedia(query):
    """Searches Wikipedia and returns a summary."""
    try:
        speak(f"Searching Wikipedia for {query}...")
        result = wikipedia.summary(query, sentences=2)
        speak(result)
        print(result)
    except wikipedia.exceptions.DisambiguationError as e:
        speak("Multiple results found. Please be more specific.")
        print("Suggestions:", e.options[:5])  # Show top 5 suggestions
    except wikipedia.exceptions.PageError:
        speak("I couldn't find any relevant Wikipedia page.")
    except Exception as e:
        speak("An error occurred while searching Wikipedia.")
        print(f"Error: {e}")      

if __name__ == "__main__":
    wishme()

    while True:
        query = takecommand()
        if not query:
            continue

        if "time" in query:
            time()
        
        elif "date" in query:
            date()

        elif "wikipedia" in query:
            query = query.replace("wikipedia", "").strip()
            search_wikipedia(query)

        elif "play music" in query:
            song_name = query.replace("play music", "").strip()
            play_music(song_name)

        elif "open youtube" in query:
            wb.open("https://www.youtube.com")

        elif "open google" in query:
            wb.open("https://www.google.com")

        elif "change your name" in query:
            set_name()
    
        elif "search in chrome" in query:
            query = query.replace("search in chrome", "").strip()
            if query:
              speak(f"Searching for {query} in Chrome.")
              wb.open(f"https://www.google.com/search?q={query}")
            else:
              speak("What do you want to search?") 

        elif "screenshot" in query:
            screenshot()
            speak("I've taken a screenshot, please check it.")

        elif "tell me a joke" in query:
            joke = pyjokes.get_joke()
            speak(joke)
            print(joke)
        elif "open whatsapp" in query:
            open_whatsapp()

        elif "shutdown" in query:
            speak("Shutting down the system, goodbye!")
            os.system("shutdown /s /f /t 1")
            break
            
        elif "restart" in query:
            speak("Restarting the system, please wait!")
            os.system("shutdown /r /f /t 1")
            break
            
        elif "go back ash" in query or "exit" in query:
            speak("Going offline. Have a good day!")
            break

